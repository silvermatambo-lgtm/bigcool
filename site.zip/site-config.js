/**
 * ULTRA MAX 7 PRO PREMIUM — CLIENT CONFIGURATION
 * Neutral DEMO preset. Replace verified business details, logo, projects,
 * review content, credentials and metrics before launching a real client site.
 * Numbers, metrics and projects in this example are explicitly demonstrative.
 * Never substitute the designer's number for a client WhatsApp destination.
 */
window.ULTRAMAX_SITE = Object.freeze({
  companyName: 'Ultra Max 7 Pro Preview',
  brandName: 'ULTRA MAX 7 PRO',
  brandInitials: 'U7',
  tagline: 'Designed to impress. Built to convert.',
  whatsappNumber: '', // e.g. 27821234567; leave blank until approved
  phoneNumber: '', // verified client contact number
  email: '',       // verified client address
  websiteUrl: '',  // final https URL, for canonical/sitemap setup
  areaServed: 'South Africa',
  industry: 'general', // general | construction | consulting | refrigeration | retail
  theme: { navy: '#081d2c', teal: '#44d8bb', tealDeep: '#087f76' },
  demoMode: true,
  serviceOptions: [], // optional override; otherwise selected industry's services
  industries: {
    general: [
      { name: 'Website & digital services', detail: 'A configurable service showcase with guided enquiries, clear deliverables and an individual call to action.', points: ['Professional consultation', 'Project scoping', 'Custom quotation'], question: 'Which type of work or solution do you have in mind?' },
      { name: 'Installation & maintenance', detail: 'Show maintenance and installation offerings with clear service coverage and customer expectations.', points: ['New installations', 'Repairs and servicing', 'Site assessment'], question: 'What needs to be installed, repaired or maintained?' },
      { name: 'Projects & consulting', detail: 'Present longer projects with case studies, a timeline and a structured request for quotation.', points: ['Planning', 'Implementation', 'Project support'], question: 'What is the goal of your project?' },
      { name: 'Other enquiry', detail: 'Not sure which option fits? Send a general enquiry and the team can help clarify your requirements.', points: ['General questions', 'Service availability', 'Next steps'], question: 'Please explain what you need help with.' }
    ],
    construction: [
      {name:'Building & renovations',detail:'Construction and renovation enquiries.',points:['New builds','Alterations','Renovations'],question:'What kind of building or renovation work is required?'},
      {name:'Painting & finishes',detail:'Interior and exterior finishes.',points:['Painting','Waterproofing','Finishes'],question:'What surfaces or areas need work?'},
      {name:'Civil works',detail:'Civil and site projects.',points:['Paving','Groundworks','Drainage'],question:'Please describe the site and civil works required.'}
    ],
    consulting: [
      {name:'Business consultation',detail:'Expert consultations.',points:['Discovery','Strategy','Support'],question:'Which business issue would you like to discuss?'},
      {name:'Project advisory',detail:'Project planning and management.',points:['Planning','Delivery','Review'],question:'What project support are you looking for?'},
      {name:'Company services',detail:'Tailored company services.',points:['Assessment','Proposal','Delivery'],question:'What business outcome are you targeting?'}
    ],
    refrigeration: [
      {name:'Air conditioning',detail:'Installation and maintenance.',points:['Installations','Repairs','Servicing'],question:'What make/model and problem are you experiencing?'},
      {name:'Cold rooms',detail:'Commercial cold room services.',points:['New rooms','Repairs','Maintenance'],question:'What size cold room and issue do you have?'},
      {name:'Fridge & freezer repairs',detail:'Appliance troubleshooting and repair.',points:['Diagnostics','Parts','Servicing'],question:'What is the appliance make/model and symptom?'}
    ],
    retail: [
      {name:'Product enquiries',detail:'Find the right product.',points:['Availability','Specifications','Pricing'],question:'Which product and quantity do you need?'},
      {name:'Bulk orders',detail:'Request a volume quotation.',points:['Sourcing','Wholesale','Delivery'],question:'Which items and quantities do you need?'},
      {name:'Delivery & support',detail:'Order and logistics assistance.',points:['Delivery','Collection','Support'],question:'What delivery or support information do you need?'}
    ]
  },
  // Use genuine approved client figures before turning off demoMode.
  stats: [
    { value: 7, suffix: '', label: 'Connected pages' },
    { value: 15, suffix: '+', label: 'Premium features' },
    { value: 3, suffix: '', label: 'Showcase slides' },
    { value: 24, suffix: '/7', label: 'Automated enquiry intake' }
  ],
  graph: [
    { label: 'Discovery', value: 30 },
    { label: 'Design', value: 60 },
    { label: 'Delivery', value: 88 }
  ],
  ring: { value: 75, label: 'Illustrative progress only' },
  timeline: [
    { title: 'Discovery', text: 'Discuss the client’s goals, audience and service areas.' },
    { title: 'Design', text: 'Plan the visual experience, content and key interactions.' },
    { title: 'Implementation', text: 'Develop the pages, assistant, galleries and PWA.' },
    { title: 'Launch', text: 'Test, approve, connect the domain and publish.' }
  ],
  beforeAfter: { before: 'assets/before.svg', after: 'assets/after.svg', title: 'Before & after interaction demo', caption: 'Illustration only — replace both images with genuine project photos.' },
  projects: [
    { title: 'Residential concept', category: 'Residential', image: 'assets/project-residential.svg', description: 'Illustrative gallery layout. Replace this artwork with an approved completed project photo.' },
    { title: 'Commercial concept', category: 'Commercial', image: 'assets/project-commercial.svg', description: 'Demonstration project card only, not a claim of completed work.' },
    { title: 'Maintenance concept', category: 'Services', image: 'assets/project-services.svg', description: 'Sample layout for a service or maintenance project.' },
    { title: 'Building concept', category: 'Residential', image: 'assets/project-residential.svg', description: 'Use a genuine client project photo and accurate description here.' },
    { title: 'Business concept', category: 'Commercial', image: 'assets/project-commercial.svg', description: 'Add the project location and year only if approved by the client.' },
    { title: 'Support concept', category: 'Services', image: 'assets/project-services.svg', description: 'Replace the example with approved client imagery.' }
  ],
  testimonials: [], // { quote, name, context } — do not invent customer testimonials
  trustItems: ['Verified business information', 'Genuine project photographs', 'Approved credentials']
});


/* Client-specific verified overrides generated by tools/build_client.py */
window.ULTRAMAX_SITE = Object.freeze({...window.ULTRAMAX_SITE, ...{
  "companyName": "Bigcool Refri & Air",
  "brandName": "BIGCOOL",
  "brandInitials": "BC",
  "shortName": "Bigcool",
  "description": "Bigcool Refri & Air provides domestic and commercial refrigeration repairs, cold and freezer rooms, mortuary room cooling, air conditioning, HVAC and ice machine services.",
  "websiteUrl": "https://bigcool.vercel.app",
  "whatsappNumber": "27636270816",
  "phoneNumber": "+27 63 627 0816",
  "email": "",
  "industry": "refrigeration",
  "areaServed": "South Africa",
  "theme": {
    "navy": "#08263d",
    "teal": "#18b6e3",
    "tealDeep": "#007eb8"
  },
  "serviceOptions": [
    "Domestic fridge repairs",
    "Commercial refrigeration",
    "Cold room building",
    "Cold room repairs",
    "Freezer rooms",
    "Mortuary rooms",
    "Air conditioner installation",
    "Air conditioner servicing",
    "Ice machines",
    "Display fridges",
    "HVAC services"
  ],
  "stats": [],
  "graph": [],
  "projects": [],
  "otherProjects": [],
  "quoteOptions": [],
  "jobDetails": [],
  "level": "",
  "ring": {
    "value": 0,
    "label": ""
  },
  "timeline": [
    {
      "title": "Tell us what you need",
      "text": "Share the appliance, installation type, or refrigeration problem."
    },
    {
      "title": "Discuss the job",
      "text": "Explain the location and requirements for a suitable assessment."
    },
    {
      "title": "Arrange service",
      "text": "Confirm the next steps directly with the Bigcool team."
    }
  ],
  "visitors": "",
  "pageDescriptions": {
    "index": "Bigcool Refri & Air: domestic and commercial fridge repairs, cold rooms, freezer rooms, air conditioning installation and servicing, and HVAC solutions.",
    "about": "Meet Bigcool Refri & Air. Refrigeration, appliance repair, air conditioning and cooling system services.",
    "services": "Domestic and commercial fridges, cold room installation, freezer rooms, mortuary room cooling, aircon, ice machines, display fridges and HVAC.",
    "gallery": "View Bigcool Refri & Air real photos of refrigeration systems, installations, cold rooms, maintenance and repair work.",
    "faq": "Answers about Bigcool domestic fridge repairs, commercial refrigeration, cold rooms, freezer rooms and air conditioning enquiries.",
    "contact": "Contact Bigcool Refri & Air on WhatsApp or call +27 63 627 0816 for appliance, refrigeration, air conditioning or cold room enquiries."
  },
  "brandLogo": "assets/bigcool-logo.webp",
  "demoMode": false
}, theme:{...window.ULTRAMAX_SITE.theme,...{"navy": "#08263d", "teal": "#18b6e3", "tealDeep": "#007eb8"}}});

window.ULTRAMAX_SITE = Object.freeze({...window.ULTRAMAX_SITE, projects:[{"title": "Air-conditioning outdoor units", "category": "Air Conditioning", "image": "assets/aircon-installation-team.webp", "description": "On-site work with multiple external air-conditioning units."}, {"title": "Refrigeration system servicing", "category": "Refrigeration", "image": "assets/refrigeration-maintenance.webp", "description": "Refrigeration equipment and service tools during on-site work."}, {"title": "Commercial cooling equipment", "category": "Refrigeration", "image": "assets/commercial-cooling-units.webp", "description": "Cooling and condenser units for commercial applications."}, {"title": "Cold room interior", "category": "Cold Rooms", "image": "assets/cold-room-interior.webp", "description": "Interior view of a cold storage room."}, {"title": "Refrigeration repair station", "category": "Repairs", "image": "assets/refrigeration-compressors.webp", "description": "Refrigeration compressors and connected pipework."}, {"title": "Aircon technician at work", "category": "Air Conditioning", "image": "assets/ac-technician-service.webp", "description": "Technician working on an external air-conditioning unit."}, {"title": "Compressor diagnostic work", "category": "Repairs", "image": "assets/compressor-repairs.webp", "description": "Diagnostic equipment for refrigeration maintenance."}, {"title": "HVAC equipment maintenance", "category": "Air Conditioning", "image": "assets/aircon-diagnostics.webp", "description": "Air-conditioning diagnostics and service equipment."}, {"title": "Refrigeration installation area", "category": "Cold Rooms", "image": "assets/commercial-cold-room-work.webp", "description": "Work around commercial refrigeration and insulated panels."}, {"title": "Equipment preparation", "category": "Repairs", "image": "assets/equipment-cleaning.webp", "description": "Technician working on appliance equipment."}, {"title": "Workshop systems", "category": "Refrigeration", "image": "assets/bigcool-workshop.webp", "description": "Business premises showing appliance repair and supply signage."}, {"title": "Aircon system components", "category": "Air Conditioning", "image": "assets/aircon-components.webp", "description": "Outdoor air-conditioning equipment and internal components."}], trustItems:["Real work photographs", "Dedicated customer enquiries", "Direct phone and WhatsApp contact"]});
