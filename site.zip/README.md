# BIGCOOL REFRI & AIR

Static seven-page rebrand of the supplied UltraMax 7 Pro Premium website, using only the attached client logo and photos.

## Pages
Home, About, Services, Gallery, FAQ, Testimonials (no fabricated reviews), Contact.

## Live contact
+27 63 627 0816 (WhatsApp: 27636270816).

## Deployment
Deploy repo root as static site on Vercel (Framework: Other; no build command). `vercel.json` already included.

## Domain
Website requested: www.bigcoolrefriandair.co.za — link only once DNS has been pointed and verified. Canonicals currently target the demo on bigcool.vercel.app.

## Photos
All site imagery originates from the attached WhatsApp photo files (optimized to WebP). No external stock photos or fabricated testimonials.

## PWA
Branded icons extracted from approved logo. Update sw.js CACHE_VERSION after future asset changes.
